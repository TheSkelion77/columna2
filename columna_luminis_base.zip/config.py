# Inserisci qui la tua chiave API e altre configurazioni
API_KEY = "INSERISCI_LA_TUA_CHIAVE_API"